
package edu.uniandes.ecos.tarea4.app.Model;

public class DatoHistorico 
{
    private String nombreParte;
    private int tamanhoParte;
    private int numeroItems;

    public DatoHistorico(String nombreParte, int tamanhoParte, int numeroItems)
    {
        this.nombreParte = nombreParte;
        this.tamanhoParte = tamanhoParte;
        this.numeroItems = numeroItems;
    }

    
    public double ln()
    {
        double cosiente = (this.tamanhoParte / this.numeroItems);
        return Math.log(cosiente);
    }

    
    public double sLnMinusAvg(double promedio)
    {
        return (this.ln() - promedio) * (this.ln() - promedio); 
    }
}
