
package edu.uniandes.ecos.tarea4.app.Model;

public class Rango 
{
    private String nombreRango;
    private double valorRango;
    
    public Rango(String nombreRango, double valorRango)
    {
        this.nombreRango = nombreRango;
        this.valorRango = valorRango;
    }

    public String getJSON()
    {
        return "{\"nombreRango\" : \"" + this.nombreRango + "\", \"valorRango\" : \"" + this.valorRango +"\"}";
    }
}
