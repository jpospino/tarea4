
package edu.uniandes.ecos.tarea4.app.Model;

import java.util.ArrayList;
import java.util.List;

public class TablaTamanhoRelativo 
{
    private List<DatoHistorico> datosHistoricos;

    
    public TablaTamanhoRelativo()
    {
        this.datosHistoricos = new ArrayList<DatoHistorico>();
    }
    
    public void addDatoHistorico(String nombreParte, int tamanhoParte, int numeroItems)
    {
        this.datosHistoricos.add(new DatoHistorico(nombreParte, tamanhoParte, numeroItems));
    }
    
    private double getAvg()
    {
        double sumatoria = 0.0;
        
        for(DatoHistorico datoHistorico: this.datosHistoricos)
        {
            sumatoria += datoHistorico.ln();
        }
        
        return sumatoria / this.datosHistoricos.size();
    }
    
    private double getVarianza()
    {
        double sumatoria = 0.0;
        double promedio = getAvg();
        
        for(DatoHistorico datoHistorico: this.datosHistoricos)
        {
            sumatoria += datoHistorico.sLnMinusAvg(promedio);
        }
        
        return (sumatoria / (this.datosHistoricos.size() - 1));
    }
    
    public String getRangos()
    {
        double desviacionStandard = Math.sqrt(getVarianza());
        double promedio = this.getAvg();
        
        Rango rangoVS = new Rango("VerySmall", Math.exp(promedio - (2 * desviacionStandard)));
        Rango rangoS = new Rango("Small", Math.exp(promedio - desviacionStandard));
        Rango rangoM = new Rango("Medium", Math.exp(promedio));
        Rango rangoL = new Rango("Large", Math.exp(promedio + desviacionStandard));
        Rango rangoVL = new Rango("VeryLarge", Math.exp(promedio + (2 * desviacionStandard)));
        
        return "[" + rangoVS.getJSON() 
                + "," + rangoS.getJSON()
                + "," + rangoM.getJSON()
                + "," + rangoL.getJSON() 
                + "," + rangoVL.getJSON()
                + "]";
    }
}
