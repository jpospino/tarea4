
package edu.uniandes.ecos.tarea4.app.Model;

import junit.framework.TestCase;

public class RangoTest extends TestCase {
    
    public RangoTest(String testName) {
        super(testName);
    }
    
    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testGetJSON() {
        System.out.println("getJSON");
        Rango rango = new Rango("VerySmall", 4.30981904117123);
        String result = rango.getJSON();
        
        assertEquals("{\"nombreRango\" : \"VerySmall\", \"valorRango\" : \"4.30981904117123\"}" , result);
    }
    
}
